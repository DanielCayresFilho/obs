<?php
/**
 * Gerenciamento de requisições AJAX
 */

if (!defined('ABSPATH')) exit;

class Campaign_Manager_Ajax {
    
    public function __construct() {
        // Registra handlers AJAX
        add_action('wp_ajax_cm_get_filters', [$this, 'get_filters']);
        add_action('wp_ajax_cm_get_count', [$this, 'get_count']);
        add_action('wp_ajax_cm_schedule_campaign', [$this, 'schedule_campaign']);
    }
    
    /**
     * Retorna filtros disponíveis para uma tabela
     */
    public function get_filters() {
        check_ajax_referer('campaign-manager-nonce', 'nonce');
        
        $table_name = isset($_POST['table_name']) ? sanitize_text_field($_POST['table_name']) : '';
        
        $filters = Campaign_Manager_Filters::get_filterable_columns($table_name);
        
        if (is_wp_error($filters)) {
            wp_send_json_error($filters->get_error_message());
        }
        
        wp_send_json_success($filters);
    }
    
    /**
     * Conta registros com filtros aplicados
     */
    public function get_count() {
        check_ajax_referer('campaign-manager-nonce', 'nonce');
        
        $table_name = isset($_POST['table_name']) ? sanitize_text_field($_POST['table_name']) : '';
        $filters_json = isset($_POST['filters']) ? stripslashes($_POST['filters']) : '[]';
        $filters = json_decode($filters_json, true);
        
        $count = Campaign_Manager_Filters::count_records($table_name, $filters);
        
        wp_send_json_success($count);
    }
    
    /**
     * Agenda uma nova campanha
     */
    public function schedule_campaign() {
        check_ajax_referer('campaign-manager-nonce', 'nonce');
        global $wpdb;
        
        // Recebe dados
        $table_name = isset($_POST['table_name']) ? sanitize_text_field($_POST['table_name']) : '';
        $filters_json = isset($_POST['filters']) ? stripslashes($_POST['filters']) : '[]';
        $filters = json_decode($filters_json, true);
        $providers_config_json = isset($_POST['providers_config']) ? stripslashes($_POST['providers_config']) : '{}';
        $providers_config = json_decode($providers_config_json, true);
        $template_id = isset($_POST['template_id']) ? intval($_POST['template_id']) : 0;
        $record_limit = isset($_POST['record_limit']) ? intval($_POST['record_limit']) : 0;
        
        // Validações
        if (empty($table_name) || empty($providers_config) || empty($template_id)) {
            wp_send_json_error('Dados da campanha inválidos.');
        }
        
        // Busca template
        $message_post = get_post($template_id);
        if (!$message_post || $message_post->post_type !== 'message_template') {
            wp_send_json_error('Template de mensagem inválido.');
        }
        $message_content = $message_post->post_content;
        
        // Busca registros
        $where_sql = Campaign_Manager_Filters::build_where_clause($filters);
        $limit_sql = $record_limit > 0 ? $wpdb->prepare(" LIMIT %d", $record_limit) : '';
        
        $select_sql = "SELECT `TELEFONE`, `NOME`, `IDGIS_AMBIENTE`, `IDCOB_CONTRATO`, `CPF` 
                       FROM `{$table_name}`" . $where_sql . $limit_sql;
        
        $records = $wpdb->get_results($select_sql, ARRAY_A);
        
        if (empty($records)) {
            wp_send_json_error('Nenhum registro encontrado com os filtros aplicados.');
        }
        
        // Distribui entre provedores
        $distributed_records = $this->distribute_records_multi_provider($records, $providers_config);
        
        $agendamento_base_id = current_time('YmdHis');
        $total_inserted = 0;
        $distribution_summary = [];
        $target_table = $wpdb->prefix . 'envios_pendentes';
        $current_user_id = get_current_user_id();
        
        foreach ($distributed_records as $provider_data) {
            $provider = $provider_data['provider'];
            $provider_records = $provider_data['records'];
            
            $prefix = strtoupper(substr($provider, 0, 1));
            $agendamento_id = $prefix . $agendamento_base_id;
            
            $inserted_count = 0;
            
            foreach ($provider_records as $record) {
                $idgis_mapeado = $this->get_mapped_idgis($table_name, $provider, $record['IDGIS_AMBIENTE']);
                
                $insert_result = $wpdb->insert(
                    $target_table,
                    [
                        'telefone' => $record['TELEFONE'],
                        'nome' => $record['NOME'],
                        'idgis_ambiente' => $idgis_mapeado,
                        'idcob_contrato' => $record['IDCOB_CONTRATO'],
                        'cpf_cnpj' => $record['CPF'],
                        'mensagem' => $message_content,
                        'fornecedor' => $provider,
                        'agendamento_id' => $agendamento_id,
                        'status' => 'pendente_aprovacao',
                        'current_user_id' => $current_user_id
                    ],
                    ['%s', '%s', '%d', '%d', '%s', '%s', '%s', '%s', '%s', '%d']
                );
                
                if ($insert_result !== false) {
                    $inserted_count++;
                }
            }
            
            $total_inserted += $inserted_count;
            $distribution_summary[] = "{$provider}: {$inserted_count}";
        }
        
        if ($total_inserted === 0) {
            wp_send_json_error('Erro ao inserir registros no banco de dados.');
        }
        
        $distribution_text = implode(' | ', $distribution_summary);
        $limit_message = $record_limit > 0 ? " (limitado a {$record_limit} registros)" : "";
        
        wp_send_json_success([
            'message' => "Campanha agendada! {$total_inserted} clientes distribuídos: {$distribution_text}{$limit_message}",
            'agendamento_id' => $agendamento_base_id
        ]);
    }
    
    /**
     * Distribui registros entre provedores
     */
    private function distribute_records_multi_provider($records, $providers_config) {
        $total_records = count($records);
        $distribution_mode = $providers_config['mode'] ?? 'split';
        $providers = $providers_config['providers'] ?? [];
        
        // Modo: enviar para todos
        if ($distribution_mode === 'all') {
            $result = [];
            foreach ($providers as $provider) {
                $result[] = [
                    'provider' => $provider,
                    'records' => $records
                ];
            }
            return $result;
        }
        
        // Modo: dividir por porcentagem
        $percentages = $providers_config['percentages'] ?? [];
        $result = [];
        
        // Normaliza porcentagens
        $total_percent = array_sum($percentages);
        if ($total_percent != 100) {
            foreach ($percentages as $provider => $percent) {
                $percentages[$provider] = ($percent / $total_percent) * 100;
            }
        }
        
        shuffle($records);
        
        $start_index = 0;
        foreach ($providers as $i => $provider) {
            $percent = $percentages[$provider] ?? 0;
            $count = round(($percent / 100) * $total_records);
            
            // Último provedor recebe o resto
            if ($i === count($providers) - 1) {
                $count = $total_records - $start_index;
            }
            
            $provider_records = array_slice($records, $start_index, $count);
            
            if (!empty($provider_records)) {
                $result[] = [
                    'provider' => $provider,
                    'records' => $provider_records
                ];
            }
            
            $start_index += $count;
        }
        
        return $result;
    }
    
    /**
     * Busca IDGIS mapeado (usa a classe CM_IDGIS_Mapper se disponível)
     */
    private function get_mapped_idgis($tabela_origem, $provedor_destino, $idgis_original) {
        if (class_exists('CM_IDGIS_Mapper')) {
            return CM_IDGIS_Mapper::get_mapped_idgis($tabela_origem, $provedor_destino, $idgis_original);
        }
        return intval($idgis_original);
    }
}