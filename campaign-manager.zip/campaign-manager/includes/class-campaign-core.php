<?php
/**
 * Classe principal do Campaign Manager
 */

if (!defined('ABSPATH')) exit;

class Campaign_Manager_Core {
    
    private $db_prefix = 'VW_BASE';
    private $ajax_handler;
    private $recurring_handler;
    
    public function __construct() {
        // Inicializa handlers
        $this->ajax_handler = new Campaign_Manager_Ajax();
        $this->recurring_handler = new Campaign_Manager_Recurring();
        
        // Registra menus
        add_action('admin_menu', [$this, 'register_menus']);
        
        // Carrega assets
        add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
    }
    
    /**
     * Registra páginas no menu do WordPress
     */
    public function register_menus() {
        // Menu principal
        add_menu_page(
            'Criar Campanha',
            'Campanhas',
            'read',
            'create-campaign',
            [$this, 'render_create_campaign_page'],
            'dashicons-email-alt',
            26
        );
        
        // Submenu: Templates Salvos
        add_submenu_page(
            'create-campaign',
            'Templates Salvos',
            'Templates Salvos',
            'read',
            'recurring-campaigns',
            [$this, 'render_recurring_page']
        );
    }
    
    /**
     * Carrega CSS e JS
     */
    public function enqueue_assets($hook) {
        if ('toplevel_page_create-campaign' !== $hook && 'campanhas_page_recurring-campaigns' !== $hook) {
            return;
        }
        
        // CSS
        wp_enqueue_style(
            'cm-styles',
            CM_ASSETS_URL . 'css/campaign-styles.css',
            [],
            CM_VERSION
        );
        
        // JS
        wp_enqueue_script(
            'cm-scripts',
            CM_ASSETS_URL . 'js/campaign-scripts.js',
            ['jquery'],
            CM_VERSION,
            true
        );
        
        // Localiza script com dados do PHP
        wp_localize_script('cm-scripts', 'cmAjax', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('campaign-manager-nonce')
        ]);
    }
    
    /**
     * Renderiza página de criação de campanha
     */
    public function render_create_campaign_page() {
        global $wpdb;
        
        // Busca tabelas disponíveis
        $tables = $wpdb->get_results("SHOW TABLES LIKE '{$this->db_prefix}%'", ARRAY_N);
        
        // Busca templates de mensagem
        $message_templates = get_posts([
            'post_type' => 'message_template',
            'posts_per_page' => -1,
            'orderby' => 'title',
            'order' => 'ASC'
        ]);
        
        // Carrega template
        include CM_TEMPLATES_DIR . 'create-campaign.php';
    }
    
    /**
     * Renderiza página de templates salvos
     */
    public function render_recurring_page() {
        include CM_TEMPLATES_DIR . 'recurring-campaigns.php';
    }
    
    /**
     * Retorna lista de provedores disponíveis
     */
    public static function get_available_providers() {
        return [
            'CDA' => 'CDA',
            'GOSAC' => 'GOSAC',
            'NOAH' => 'NOAH',
            'SALESFORCE' => 'Salesforce',
            'RCS' => 'RCS Ótima'
        ];
    }
}