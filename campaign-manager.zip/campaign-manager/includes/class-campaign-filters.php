<?php
/**
 * Gerenciamento de filtros de campanhas
 */

if (!defined('ABSPATH')) exit;

class Campaign_Manager_Filters {
    
    /**
     * ⚡ COLUNAS QUE NÃO DEVEM APARECER NOS FILTROS
     * Adicione ou remova colunas aqui conforme necessário
     */
    private static $excluded_columns = [
        'TELEFONE',
        'NOME',
        'IDGIS_AMBIENTE',
        'IDCOB_CONTRATO',
        'CPF',
        'CPF_CNPJ',
        'DATA_ATUALIZACAO',
        'DATA_CRIACAO',
        'DATA_INCLUSAO',
        'IDCOB_CLIENTE',
        'ID',
        'CODIGO_CLIENTE',
        'CONTRATO',
        'VENCIMENTO_BOLETO',
        'ULT_FUP',
        'OPERADORA',
        'placa'
    ];
    
    /**
     * Retorna as colunas disponíveis para filtro de uma tabela
     */
    public static function get_filterable_columns($table_name) {
        global $wpdb;
        
        if (empty($table_name)) {
            return new WP_Error('invalid_table', 'Nome de tabela inválido');
        }
        
        // Busca informações das colunas
        $columns_info = $wpdb->get_results($wpdb->prepare(
            "SELECT COLUMN_NAME, DATA_TYPE 
             FROM INFORMATION_SCHEMA.COLUMNS 
             WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s",
            DB_NAME,
            $table_name
        ), ARRAY_A);
        
        if (empty($columns_info)) {
            return new WP_Error('no_columns', 'Não foi possível obter colunas da tabela');
        }
        
        $numeric_types = ['int', 'bigint', 'decimal', 'float', 'double', 'tinyint', 'smallint', 'mediumint', 'real'];
        $categorical_threshold = 50;
        $filters = [];
        
        foreach ($columns_info as $column) {
            $column_name = $column['COLUMN_NAME'];
            $data_type = strtolower($column['DATA_TYPE']);
            
            // ⚡ PULA COLUNAS EXCLUÍDAS
            if (in_array(strtoupper($column_name), self::$excluded_columns)) {
                continue;
            }
            
            $is_numeric = in_array($data_type, $numeric_types);
            
            // Conta valores distintos
            $distinct_count = $wpdb->get_var(
                "SELECT COUNT(DISTINCT `{$column_name}`) 
                 FROM `{$table_name}` 
                 WHERE `{$column_name}` IS NOT NULL"
            );
            
            // Se for numérico e tem muitos valores únicos, é filtro numérico
            if ($is_numeric && $distinct_count > $categorical_threshold) {
                $filters[$column_name] = [
                    'type' => 'numeric',
                    'data_type' => $data_type
                ];
            } else {
                // É categórico, busca os valores únicos
                $values = $wpdb->get_col(
                    "SELECT DISTINCT `{$column_name}` 
                     FROM `{$table_name}` 
                     WHERE `{$column_name}` IS NOT NULL 
                     AND `{$column_name}` != '' 
                     ORDER BY `{$column_name}` ASC
                     LIMIT 100"
                );
                
                if (!empty($values)) {
                    $filters[$column_name] = [
                        'type' => 'categorical',
                        'values' => $values,
                        'count' => count($values)
                    ];
                }
            }
        }
        
        return $filters;
    }
    
    /**
     * Constrói cláusula WHERE baseada nos filtros
     */
    public static function build_where_clause($filters) {
        global $wpdb;
        
        $where_clauses = ['1=1'];
        $allowed_operators = ['=', '!=', '>', '<', '>=', '<=', 'IN'];
        
        if (empty($filters) || !is_array($filters)) {
            return ' WHERE 1=1';
        }
        
        foreach ($filters as $column => $filter_data) {
            if (!is_array($filter_data) || empty($filter_data['operator'])) {
                continue;
            }
            
            if (!isset($filter_data['value']) || $filter_data['value'] === '') {
                continue;
            }
            
            $sanitized_column = esc_sql(str_replace('`', '', $column));
            $operator = strtoupper($filter_data['operator']);
            $value = $filter_data['value'];
            
            if (!in_array($operator, $allowed_operators)) {
                continue;
            }
            
            // Operador IN para múltiplos valores
            if ($operator === 'IN') {
                if (!is_array($value) || empty($value)) {
                    continue;
                }
                $placeholders = implode(', ', array_fill(0, count($value), '%s'));
                $where_clauses[] = $wpdb->prepare(
                    "`{$sanitized_column}` IN ({$placeholders})",
                    $value
                );
            } else {
                // Operadores simples
                $where_clauses[] = $wpdb->prepare(
                    "`{$sanitized_column}` {$operator} %s",
                    $value
                );
            }
        }
        
        return ' WHERE ' . implode(' AND ', $where_clauses);
    }
    
    /**
     * Conta registros com filtros aplicados
     */
    public static function count_records($table_name, $filters) {
        global $wpdb;
        
        if (empty($table_name)) {
            return 0;
        }
        
        $where_sql = self::build_where_clause($filters);
        $count = $wpdb->get_var("SELECT COUNT(*) FROM `{$table_name}`" . $where_sql);
        
        return intval($count);
    }
}