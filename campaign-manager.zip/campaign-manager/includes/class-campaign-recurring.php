<?php
/**
 * Gerenciamento de campanhas recorrentes (templates salvos)
 */

if (!defined('ABSPATH')) exit;

class Campaign_Manager_Recurring {
    
    private $table;
    
    public function __construct() {
        global $wpdb;
        $this->table = $wpdb->prefix . 'cm_recurring_campaigns';
        
        // Registra handlers AJAX
        add_action('wp_ajax_cm_save_recurring', [$this, 'save_recurring']);
        add_action('wp_ajax_cm_get_recurring', [$this, 'get_recurring']);
        add_action('wp_ajax_cm_delete_recurring', [$this, 'delete_recurring']);
        add_action('wp_ajax_cm_toggle_recurring', [$this, 'toggle_recurring']);
        add_action('wp_ajax_cm_execute_recurring_now', [$this, 'execute_recurring_now']);
        add_action('wp_ajax_cm_preview_recurring_count', [$this, 'preview_recurring_count']);
    }
    
    /**
     * Salva um novo template de campanha
     */
    public function save_recurring() {
        check_ajax_referer('campaign-manager-nonce', 'nonce');
        global $wpdb;
        
        $nome_campanha = sanitize_text_field($_POST['nome_campanha'] ?? '');
        $table_name = sanitize_text_field($_POST['table_name'] ?? '');
        $filters_json = stripslashes($_POST['filters'] ?? '[]');
        $providers_config_json = stripslashes($_POST['providers_config'] ?? '{}');
        $template_id = intval($_POST['template_id'] ?? 0);
        $record_limit = intval($_POST['record_limit'] ?? 0);
        
        if (empty($nome_campanha) || empty($table_name) || empty($template_id)) {
            wp_send_json_error('Dados incompletos para criar template.');
        }
        
        $result = $wpdb->insert(
            $this->table,
            [
                'nome_campanha' => $nome_campanha,
                'tabela_origem' => $table_name,
                'filtros_json' => $filters_json,
                'providers_config' => $providers_config_json,
                'template_id' => $template_id,
                'record_limit' => $record_limit,
                'ativo' => 1,
                'criado_por' => get_current_user_id()
            ],
            ['%s', '%s', '%s', '%s', '%d', '%d', '%d', '%d']
        );
        
        if ($result === false) {
            wp_send_json_error('Erro ao salvar template: ' . $wpdb->last_error);
        }
        
        wp_send_json_success('Template salvo com sucesso!');
    }
    
    /**
     * Lista todos os templates salvos
     */
    public function get_recurring() {
        check_ajax_referer('campaign-manager-nonce', 'nonce');
        global $wpdb;
        
        $campaigns = $wpdb->get_results(
            "SELECT * FROM {$this->table} ORDER BY criado_em DESC",
            ARRAY_A
        );
        
        wp_send_json_success($campaigns);
    }
    
    /**
     * Deleta um template
     */
    public function delete_recurring() {
        check_ajax_referer('campaign-manager-nonce', 'nonce');
        global $wpdb;
        
        $id = intval($_POST['id'] ?? 0);
        if ($id <= 0) {
            wp_send_json_error('ID inválido.');
        }
        
        $result = $wpdb->delete($this->table, ['id' => $id], ['%d']);
        
        if ($result === false) {
            wp_send_json_error('Erro ao deletar template.');
        }
        
        wp_send_json_success('Template deletado!');
    }
    
    /**
     * Ativa/desativa um template
     */
    public function toggle_recurring() {
        check_ajax_referer('campaign-manager-nonce', 'nonce');
        global $wpdb;
        
        $id = intval($_POST['id'] ?? 0);
        $ativo = intval($_POST['ativo'] ?? 0);
        
        if ($id <= 0) {
            wp_send_json_error('ID inválido.');
        }
        
        $result = $wpdb->update(
            $this->table,
            ['ativo' => $ativo],
            ['id' => $id],
            ['%d'],
            ['%d']
        );
        
        if ($result === false) {
            wp_send_json_error('Erro ao atualizar status.');
        }
        
        wp_send_json_success($ativo ? 'Template ativado!' : 'Template desativado!');
    }
    
    /**
     * Preview: conta quantos registros serão afetados
     */
    public function preview_recurring_count() {
        check_ajax_referer('campaign-manager-nonce', 'nonce');
        global $wpdb;
        
        $id = intval($_POST['id'] ?? 0);
        if ($id <= 0) {
            wp_send_json_error('ID inválido.');
        }
        
        $campaign = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->table} WHERE id = %d",
            $id
        ), ARRAY_A);
        
        if (!$campaign) {
            wp_send_json_error('Template não encontrado.');
        }
        
        $filters = json_decode($campaign['filtros_json'], true);
        $total_count = Campaign_Manager_Filters::count_records($campaign['tabela_origem'], $filters);
        
        $final_count = $campaign['record_limit'] > 0 ? min($total_count, $campaign['record_limit']) : $total_count;
        
        wp_send_json_success([
            'count' => $final_count,
            'total_available' => $total_count,
            'has_limit' => $campaign['record_limit'] > 0
        ]);
    }
    
    /**
     * Executa um template agora
     */
    public function execute_recurring_now() {
        check_ajax_referer('campaign-manager-nonce', 'nonce');
        global $wpdb;
        
        $id = intval($_POST['id'] ?? 0);
        if ($id <= 0) {
            wp_send_json_error('ID inválido.');
        }
        
        $campaign = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->table} WHERE id = %d",
            $id
        ), ARRAY_A);
        
        if (!$campaign) {
            wp_send_json_error('Template não encontrado.');
        }
        
        $result = $this->execute_campaign($campaign);
        
        // Atualiza última execução
        $wpdb->update(
            $this->table,
            ['ultima_execucao' => current_time('mysql')],
            ['id' => $id],
            ['%s'],
            ['%d']
        );
        
        if ($result['success']) {
            wp_send_json_success([
                'message' => $result['message'],
                'details' => $result
            ]);
        } else {
            wp_send_json_error($result['message']);
        }
    }
    
    /**
     * Executa uma campanha recorrente
     */
    private function execute_campaign($campaign) {
        global $wpdb;
        
        $filters = json_decode($campaign['filtros_json'], true);
        $providers_config = json_decode($campaign['providers_config'], true);
        
        // Busca registros
        $where_sql = Campaign_Manager_Filters::build_where_clause($filters);
        $limit_sql = $campaign['record_limit'] > 0 ? $wpdb->prepare(" LIMIT %d", $campaign['record_limit']) : '';
        
        $select_sql = "SELECT `TELEFONE`, `NOME`, `IDGIS_AMBIENTE`, `IDCOB_CONTRATO`, `CPF` 
                       FROM `{$campaign['tabela_origem']}`" . $where_sql . $limit_sql;
        
        $records = $wpdb->get_results($select_sql, ARRAY_A);
        
        if (empty($records)) {
            return [
                'success' => false,
                'message' => 'Nenhum registro encontrado'
            ];
        }
        
        // Busca template
        $message_post = get_post($campaign['template_id']);
        if (!$message_post) {
            return [
                'success' => false,
                'message' => 'Template não encontrado'
            ];
        }
        
        $message_content = $message_post->post_content;
        
        // Distribui e insere
        $ajax_handler = new Campaign_Manager_Ajax();
        $distributed = $ajax_handler->distribute_records_multi_provider($records, $providers_config);
        
        $target_table = $wpdb->prefix . 'envios_pendentes';
        $timestamp = current_time('YmdHis');
        $total_inserted = 0;
        
        foreach ($distributed as $provider_data) {
            $provider = $provider_data['provider'];
            $provider_records = $provider_data['records'];
            
            $prefix = strtoupper(substr($provider, 0, 1));
            $agendamento_id = "{$prefix}{$timestamp}";
            
            foreach ($provider_records as $record) {
                $wpdb->insert(
                    $target_table,
                    [
                        'telefone' => $record['TELEFONE'],
                        'nome' => $record['NOME'],
                        'idgis_ambiente' => $record['IDGIS_AMBIENTE'],
                        'idcob_contrato' => $record['IDCOB_CONTRATO'],
                        'cpf_cnpj' => $record['CPF'],
                        'mensagem' => $message_content,
                        'fornecedor' => $provider,
                        'agendamento_id' => $agendamento_id,
                        'status' => 'pendente_aprovacao',
                        'current_user_id' => $campaign['criado_por']
                    ],
                    ['%s', '%s', '%d', '%d', '%s', '%s', '%s', '%s', '%s', '%d']
                );
                
                if ($wpdb->insert_id) {
                    $total_inserted++;
                }
            }
        }
        
        return [
            'success' => true,
            'message' => "{$total_inserted} registros inseridos com sucesso",
            'records_inserted' => $total_inserted
        ];
    }
}