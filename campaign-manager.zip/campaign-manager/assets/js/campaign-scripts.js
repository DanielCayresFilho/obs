/**
 * Campaign Manager - JavaScript
 * Version: 3.0.0
 */

jQuery(document).ready(function($) {
    let currentStep = 1;
    let selectedTable = '';
    let availableFilters = {};
    let currentFilters = {};
    let audienceCount = 0;

    // ===== STEP 1: SELECIONAR TABELA =====
    $('#data-source-select').on('change', function() {
        selectedTable = $(this).val();
        
        if (selectedTable) {
            loadFilters(selectedTable);
        }
    });

    // ===== CARREGAR FILTROS =====
    function loadFilters(tableName) {
        $('#filters-container').html('<p>⏳ Carregando filtros...</p>');
        
        $.ajax({
            url: cmAjax.ajax_url,
            type: 'POST',
            data: {
                action: 'cm_get_filters',
                nonce: cmAjax.nonce,
                table_name: tableName
            },
            success: function(response) {
                if (response.success) {
                    availableFilters = response.data;
                    renderFilters(availableFilters);
                    goToStep(2);
                    updateAudienceCount();
                } else {
                    alert('Erro: ' + response.data);
                }
            },
            error: function() {
                alert('Erro de conexão');
            }
        });
    }

    // ===== RENDERIZAR FILTROS =====
    function renderFilters(filters) {
        const container = $('#filters-container');
        container.empty();

        if (Object.keys(filters).length === 0) {
            container.html('<p>Nenhum filtro disponível.</p>');
            $('#continue-to-step-3').show();
            return;
        }

        Object.keys(filters).forEach(function(columnName) {
            const filterData = filters[columnName];
            const filterDiv = $('<div class="cm-filter-group"></div>');
            
            filterDiv.append(`<label>${columnName}</label>`);

            // FILTRO NUMÉRICO
            if (filterData.type === 'numeric') {
                const numericDiv = $('<div class="cm-numeric-filter"></div>');
                
                const operatorSelect = $(`
                    <select class="cm-select filter-operator" data-column="${columnName}">
                        <option value="">--</option>
                        <option value="=">=</option>
                        <option value="!=">≠</option>
                        <option value=">">></option>
                        <option value="<"><</option>
                        <option value=">=">≥</option>
                        <option value="<=">≤</option>
                    </select>
                `);
                
                const valueInput = $(`
                    <input type="number" class="cm-input filter-value" 
                           data-column="${columnName}" placeholder="Valor" disabled>
                `);

                operatorSelect.on('change', function() {
                    valueInput.prop('disabled', !$(this).val());
                    if (!$(this).val()) {
                        valueInput.val('');
                        delete currentFilters[columnName];
                        updateAudienceCount();
                    }
                });

                valueInput.on('input', debounce(function() {
                    const operator = operatorSelect.val();
                    const value = $(this).val();
                    
                    if (operator && value !== '') {
                        currentFilters[columnName] = {
                            operator: operator,
                            value: value
                        };
                        updateAudienceCount();
                    }
                }, 500));

                numericDiv.append(operatorSelect).append(valueInput);
                filterDiv.append(numericDiv);
            } 
            // FILTRO CATEGÓRICO (CHECKBOXES)
            else if (filterData.type === 'categorical') {
                const checkboxGrid = $('<div class="cm-checkbox-grid"></div>');
                
                filterData.values.forEach(function(value) {
                    const checkboxItem = $(`
                        <label class="cm-checkbox-item">
                            <input type="checkbox" class="filter-checkbox" 
                                   data-column="${columnName}" value="${value}">
                            <span>${value}</span>
                        </label>
                    `);
                    checkboxGrid.append(checkboxItem);
                });

                // Evento de mudança nos checkboxes
                checkboxGrid.on('change', '.filter-checkbox', function() {
                    const column = $(this).data('column');
                    const checkedValues = [];
                    
                    $(`.filter-checkbox[data-column="${column}"]:checked`).each(function() {
                        checkedValues.push($(this).val());
                    });

                    if (checkedValues.length > 0) {
                        currentFilters[column] = {
                            operator: 'IN',
                            value: checkedValues
                        };
                    } else {
                        delete currentFilters[column];
                    }
                    
                    updateAudienceCount();
                });

                filterDiv.append(checkboxGrid);
            }

            container.append(filterDiv);
        });

        $('#continue-to-step-3').show();
    }

    // ===== ATUALIZAR CONTAGEM =====
    function updateAudienceCount() {
        if (!selectedTable) return;
        
        $('#audience-count').text('...');
        
        $.ajax({
            url: cmAjax.ajax_url,
            type: 'POST',
            data: {
                action: 'cm_get_count',
                nonce: cmAjax.nonce,
                table_name: selectedTable,
                filters: JSON.stringify(currentFilters)
            },
            success: function(response) {
                if (response.success) {
                    audienceCount = parseInt(response.data) || 0;
                    $('#audience-count').text(audienceCount.toLocaleString('pt-BR'));
                }
            }
        });
    }

    // ===== STEP 3: CONTINUAR =====
    $('#continue-to-step-3').on('click', function() {
        goToStep(3);
    });

    // ===== VALIDAÇÃO STEP 3 =====
    function validateStep3() {
        const templateSelected = $('#template-select').val() !== '';
        const providersSelected = $('.provider-checkbox:checked').length > 0;
        const schedulingMode = $('input[name="scheduling_mode"]:checked').val();
        const campaignName = $('#campaign-name').val().trim();

        let isValid = false;

        if (schedulingMode === 'recurring') {
            isValid = campaignName && templateSelected && providersSelected;
        } else {
            isValid = templateSelected && providersSelected;
        }

        $('#schedule-campaign-btn').prop('disabled', !isValid);
    }

    $('#template-select, #campaign-name').on('change input', validateStep3);
    $(document).on('change', '.provider-checkbox', validateStep3);
    $('input[name="scheduling_mode"]').on('change', function() {
        const mode = $(this).val();
        
        if (mode === 'recurring') {
            $('#recurring-options').slideDown();
            $('#schedule-campaign-btn').text('Salvar Template');
        } else {
            $('#recurring-options').slideUp();
            $('#schedule-campaign-btn').text('Agendar Campanha');
        }
        
        validateStep3();
    });

    // ===== DISTRIBUIÇÃO DE PROVEDORES =====
    $('input[name="distribution_mode"]').on('change', function() {
        const mode = $(this).val();
        $('.provider-percent').prop('disabled', mode === 'all');
    });

    // ===== AGENDAR CAMPANHA =====
    $('#schedule-campaign-btn').on('click', function() {
        const btn = $(this);
        const schedulingMode = $('input[name="scheduling_mode"]:checked').val();
        
        const templateId = $('#template-select').val();
        const selectedProviders = [];
        const percentages = {};
        
        $('.provider-checkbox:checked').each(function() {
            const provider = $(this).val();
            selectedProviders.push(provider);
            const percent = parseInt($(`.provider-percent[data-provider="${provider}"]`).val()) || 0;
            percentages[provider] = percent;
        });

        const distributionMode = $('input[name="distribution_mode"]:checked').val();
        const providersConfig = {
            mode: distributionMode,
            providers: selectedProviders,
            percentages: percentages
        };

        const recordLimit = parseInt($('#record-limit').val()) || 0;

        btn.prop('disabled', true).text('⏳ Processando...');

        // MODO TEMPLATE
        if (schedulingMode === 'recurring') {
            const campaignName = $('#campaign-name').val().trim();
            
            $.ajax({
                url: cmAjax.ajax_url,
                type: 'POST',
                data: {
                    action: 'cm_save_recurring',
                    nonce: cmAjax.nonce,
                    nome_campanha: campaignName,
                    table_name: selectedTable,
                    filters: JSON.stringify(currentFilters),
                    providers_config: JSON.stringify(providersConfig),
                    template_id: templateId,
                    record_limit: recordLimit
                },
                success: function(response) {
                    if (response.success) {
                        showMessage('✅ ' + response.data, 'success');
                        setTimeout(() => window.location.href = '?page=recurring-campaigns', 1500);
                    } else {
                        showMessage('❌ ' + response.data, 'error');
                        btn.prop('disabled', false).text('Salvar Template');
                    }
                }
            });
        } 
        // MODO IMEDIATO
        else {
            $.ajax({
                url: cmAjax.ajax_url,
                type: 'POST',
                data: {
                    action: 'cm_schedule_campaign',
                    nonce: cmAjax.nonce,
                    table_name: selectedTable,
                    filters: JSON.stringify(currentFilters),
                    providers_config: JSON.stringify(providersConfig),
                    template_id: templateId,
                    record_limit: recordLimit
                },
                success: function(response) {
                    if (response.success) {
                        showMessage('✅ ' + response.data.message, 'success');
                        setTimeout(() => location.reload(), 2000);
                    } else {
                        showMessage('❌ ' + response.data, 'error');
                        btn.prop('disabled', false).text('Agendar Campanha');
                    }
                }
            });
        }
    });

    // ===== NAVEGAÇÃO =====
    function goToStep(step) {
        currentStep = step;

        $('.cm-progress-step').removeClass('active completed');
        for (let i = 1; i < step; i++) {
            $(`.cm-progress-step[data-step="${i}"]`).addClass('completed');
        }
        $(`.cm-progress-step[data-step="${step}"]`).addClass('active');

        $('.cm-card').hide();
        $(`#step-${step}-box, #step-${step}-filters, #step-${step}-details`).show();
    }

    $('.cm-progress-step').on('click', function() {
        const targetStep = parseInt($(this).data('step'));
        if (targetStep <= currentStep) {
            goToStep(targetStep);
        }
    });

    // ===== UTILS =====
    function showMessage(text, type) {
        $('#schedule-message').removeClass('success error').addClass(type).html(text).show();
    }

    function debounce(func, wait) {
        let timeout;
        return function(...args) {
            clearTimeout(timeout);
            timeout = setTimeout(() => func.apply(this, args), wait);
        };
    }

    // Inicialização
    validateStep3();
});