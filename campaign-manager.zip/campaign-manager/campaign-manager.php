<?php
/**
 * Plugin Name: Campaign Manager Pro
 * Description: Sistema modular de gerenciamento de campanhas com suporte a múltiplos provedores (CDA, GOSAC, NOAH, SALESFORCE, RCS)
 * Version: 3.0.0
 * Author: Daniel Cayres
 */

if (!defined('ABSPATH')) exit;

// Define constantes do plugin
define('CM_VERSION', '3.0.0');
define('CM_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('CM_PLUGIN_URL', plugin_dir_url(__FILE__));
define('CM_INCLUDES_DIR', CM_PLUGIN_DIR . 'includes/');
define('CM_TEMPLATES_DIR', CM_PLUGIN_DIR . 'templates/');
define('CM_ASSETS_URL', CM_PLUGIN_URL . 'assets/');

/**
 * Carrega os arquivos necessários
 */
function cm_load_dependencies() {
    require_once CM_INCLUDES_DIR . 'class-campaign-filters.php';
    require_once CM_INCLUDES_DIR . 'class-campaign-ajax.php';
    require_once CM_INCLUDES_DIR . 'class-campaign-recurring.php';
    require_once CM_INCLUDES_DIR . 'class-idgis-mapper.php';
    require_once CM_INCLUDES_DIR . 'class-robbu-mapper.php';
    require_once CM_INCLUDES_DIR . 'class-campaign-core.php';
}
add_action('plugins_loaded', 'cm_load_dependencies');

/**
 * Inicializa o plugin
 */
function cm_init_plugin() {
    new Campaign_Manager_Core();
}
add_action('init', 'cm_init_plugin');

/**
 * Ativação do plugin - Cria tabelas necessárias
 */
function cm_activate_plugin() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    
    // Tabela de campanhas recorrentes
    $table_recurring = $wpdb->prefix . 'cm_recurring_campaigns';
    $sql_recurring = "CREATE TABLE IF NOT EXISTS $table_recurring (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        nome_campanha varchar(255) NOT NULL,
        tabela_origem varchar(150) NOT NULL,
        filtros_json text,
        providers_config text NOT NULL,
        template_id bigint(20) NOT NULL,
        record_limit int(11) DEFAULT 0,
        ativo tinyint(1) DEFAULT 1,
        ultima_execucao datetime DEFAULT NULL,
        criado_por bigint(20) NOT NULL,
        criado_em datetime DEFAULT CURRENT_TIMESTAMP,
        atualizado_em datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset_collate;";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql_recurring);
    
    flush_rewrite_rules();
}
register_activation_hook(__FILE__, 'cm_activate_plugin');

/**
 * Desativação do plugin
 */
function cm_deactivate_plugin() {
    flush_rewrite_rules();
}
register_deactivation_hook(__FILE__, 'cm_deactivate_plugin');