<?php
/**
 * Template: Templates Salvos (Campanhas Recorrentes)
 */

if (!defined('ABSPATH')) exit;
?>

<div class="cm-wrap">
    <div class="cm-header">
        <div class="cm-header-icon">📋</div>
        <div>
            <h1>Templates Salvos</h1>
            <p>Execute seus templates de campanha quando quiser</p>
        </div>
    </div>

    <div id="recurring-campaigns-list" class="cm-templates-grid"></div>
</div>

<style>
.cm-templates-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
    gap: 20px;
}

.cm-template-card {
    background: white;
    border-radius: 12px;
    padding: 20px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    transition: all 0.3s;
}

.cm-template-card:hover {
    box-shadow: 0 10px 25px rgba(0,0,0,0.1);
    transform: translateY(-2px);
}

.cm-template-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 15px;
}

.cm-template-title {
    font-size: 18px;
    font-weight: 700;
    color: #111827;
    margin: 0 0 5px 0;
}

.cm-template-badge {
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
}

.cm-template-badge.active {
    background: #d1fae5;
    color: #065f46;
}

.cm-template-badge.inactive {
    background: #fee2e2;
    color: #991b1b;
}

.cm-template-meta {
    font-size: 13px;
    color: #6b7280;
    margin-bottom: 10px;
}

.cm-template-count {
    background: #dbeafe;
    padding: 10px;
    border-radius: 8px;
    text-align: center;
    margin: 15px 0;
    font-weight: 700;
    color: #1e40af;
}

.cm-template-actions {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}

.cm-template-btn {
    padding: 8px 16px;
    border: none;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s;
}

.cm-template-btn-primary {
    background: #6366f1;
    color: white;
}

.cm-template-btn-primary:hover {
    background: #4f46e5;
}

.cm-template-btn-secondary {
    background: #f3f4f6;
    color: #374151;
}

.cm-template-btn-secondary:hover {
    background: #e5e7eb;
}

.cm-template-btn-danger {
    background: #fee2e2;
    color: #991b1b;
}

.cm-template-btn-danger:hover {
    background: #fecaca;
}
</style>

<script>
jQuery(document).ready(function($) {
    loadTemplates();

    function loadTemplates() {
        $.ajax({
            url: cmAjax.ajax_url,
            type: 'POST',
            data: {
                action: 'cm_get_recurring',
                nonce: cmAjax.nonce
            },
            success: function(response) {
                if (response.success) {
                    renderTemplates(response.data);
                }
            }
        });
    }

    function renderTemplates(templates) {
        const container = $('#recurring-campaigns-list');
        container.empty();

        if (templates.length === 0) {
            container.html('<p>Nenhum template salvo ainda.</p>');
            return;
        }

        templates.forEach(function(template) {
            const providersConfig = JSON.parse(template.providers_config);
            const providers = providersConfig.providers.join(', ');
            const statusBadge = template.ativo == 1 
                ? '<span class="cm-template-badge active">✓ Ativo</span>' 
                : '<span class="cm-template-badge inactive">✗ Inativo</span>';

            const card = $(`
                <div class="cm-template-card">
                    <div class="cm-template-header">
                        <div>
                            <h3 class="cm-template-title">${template.nome_campanha}</h3>
                            <div class="cm-template-meta">📊 ${template.tabela_origem}</div>
                            <div class="cm-template-meta">🌐 ${providers}</div>
                        </div>
                        ${statusBadge}
                    </div>
                    
                    <div class="cm-template-count" data-id="${template.id}">
                        ⏳ Carregando...
                    </div>
                    
                    <div class="cm-template-actions">
                        <button class="cm-template-btn cm-template-btn-primary execute-now" data-id="${template.id}">
                            ▶️ Executar
                        </button>
                        <button class="cm-template-btn cm-template-btn-secondary toggle-status" 
                                data-id="${template.id}" data-ativo="${template.ativo}">
                            ${template.ativo == 1 ? '⏸️ Desativar' : '▶️ Ativar'}
                        </button>
                        <button class="cm-template-btn cm-template-btn-danger delete-template" data-id="${template.id}">
                            🗑️ Deletar
                        </button>
                    </div>
                </div>
            `);

            container.append(card);
            loadCount(template.id);
        });
    }

    function loadCount(id) {
        $.ajax({
            url: cmAjax.ajax_url,
            type: 'POST',
            data: {
                action: 'cm_preview_recurring_count',
                nonce: cmAjax.nonce,
                id: id
            },
            success: function(response) {
                if (response.success) {
                    const count = response.data.count.toLocaleString('pt-BR');
                    $(`.cm-template-count[data-id="${id}"]`).text(`👥 ${count} registros`);
                }
            }
        });
    }

    $(document).on('click', '.execute-now', function() {
        if (!confirm('⚡ Executar este template agora?')) return;

        const id = $(this).data('id');
        const btn = $(this);
        
        btn.prop('disabled', true).text('⏳ Executando...');

        $.ajax({
            url: cmAjax.ajax_url,
            type: 'POST',
            data: {
                action: 'cm_execute_recurring_now',
                nonce: cmAjax.nonce,
                id: id
            },
            success: function(response) {
                if (response.success) {
                    alert('✅ ' + response.data.message);
                    loadTemplates();
                } else {
                    alert('❌ ' + response.data);
                    btn.prop('disabled', false).text('▶️ Executar');
                }
            }
        });
    });

    $(document).on('click', '.toggle-status', function() {
        const id = $(this).data('id');
        const ativo = $(this).data('ativo') == 1 ? 0 : 1;

        $.ajax({
            url: cmAjax.ajax_url,
            type: 'POST',
            data: {
                action: 'cm_toggle_recurring',
                nonce: cmAjax.nonce,
                id: id,
                ativo: ativo
            },
            success: function(response) {
                if (response.success) {
                    loadTemplates();
                }
            }
        });
    });

    $(document).on('click', '.delete-template', function() {
        if (!confirm('⚠️ Deletar este template? Esta ação não pode ser desfeita!')) return;

        const id = $(this).data('id');

        $.ajax({
            url: cmAjax.ajax_url,
            type: 'POST',
            data: {
                action: 'cm_delete_recurring',
                nonce: cmAjax.nonce,
                id: id
            },
            success: function(response) {
                if (response.success) {
                    loadTemplates();
                }
            }
        });
    });
});
</script>