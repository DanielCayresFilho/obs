<?php
/**
 * Template: Criar Nova Campanha
 * Variáveis disponíveis: $tables, $message_templates
 */

if (!defined('ABSPATH')) exit;

$providers = Campaign_Manager_Core::get_available_providers();
?>

<div class="cm-wrap">
    <!-- Header -->
    <div class="cm-header">
        <div class="cm-header-icon">📧</div>
        <div>
            <h1>Criar Nova Campanha</h1>
            <p>Configure e agende suas campanhas multiplataforma</p>
        </div>
    </div>

    <!-- Progress Bar -->
    <div class="cm-progress">
        <div class="cm-progress-step active" data-step="1">
            <div class="cm-progress-dot">1</div>
            <span>Base</span>
        </div>
        <div class="cm-progress-line"></div>
        <div class="cm-progress-step" data-step="2">
            <div class="cm-progress-dot">2</div>
            <span>Filtros</span>
        </div>
        <div class="cm-progress-line"></div>
        <div class="cm-progress-step" data-step="3">
            <div class="cm-progress-dot">3</div>
            <span>Detalhes</span>
        </div>
    </div>

    <!-- Step 1: Selecionar Base -->
    <div class="cm-card" id="step-1-box">
        <div class="cm-card-header">
            <span class="cm-card-icon">🗄️</span>
            <div>
                <h2>Selecione a Base de Dados</h2>
                <p>Escolha a fonte dos seus clientes</p>
            </div>
        </div>
        <div class="cm-card-body">
            <select id="data-source-select" class="cm-select">
                <option value="">-- Escolha uma base --</option>
                <?php foreach ($tables as $table): ?>
                    <option value="<?php echo esc_attr($table[0]); ?>">
                        <?php echo esc_html($table[0]); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
    </div>

    <!-- Step 2: Filtros -->
    <div class="cm-card" id="step-2-filters" style="display:none;">
        <div class="cm-card-header">
            <span class="cm-card-icon">🔍</span>
            <div>
                <h2>Filtre sua Audiência</h2>
                <p>Defina critérios de segmentação</p>
            </div>
        </div>
        <div class="cm-card-body">
            <div id="filters-container"></div>
            
            <div class="cm-audience-badge">
                <span class="cm-audience-icon">👥</span>
                <div>
                    <div class="cm-audience-count" id="audience-count">0</div>
                    <div class="cm-audience-label">clientes selecionados</div>
                </div>
            </div>

            <button id="continue-to-step-3" class="cm-btn cm-btn-primary" style="display:none;">
                Continuar →
            </button>
        </div>
    </div>

    <!-- Step 3: Detalhes -->
    <div class="cm-card" id="step-3-details" style="display:none;">
        <div class="cm-card-header">
            <span class="cm-card-icon">⚙️</span>
            <div>
                <h2>Detalhes da Campanha</h2>
                <p>Configure template e provedores</p>
            </div>
        </div>
        <div class="cm-card-body">
            
            <!-- Template -->
            <div class="cm-form-group">
                <label>📄 Template da Mensagem</label>
                <select id="template-select" class="cm-select">
                    <option value="">-- Escolha um template --</option>
                    <?php foreach ($message_templates as $template): ?>
                        <option value="<?php echo esc_attr($template->ID); ?>">
                            <?php echo esc_html($template->post_title); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Provedores -->
            <div class="cm-section">
                <h3>🌐 Provedores de Envio</h3>
                
                <div class="cm-radio-group">
                    <label class="cm-radio">
                        <input type="radio" name="distribution_mode" value="split" checked>
                        <span>Dividir audiência entre provedores</span>
                    </label>
                    <label class="cm-radio">
                        <input type="radio" name="distribution_mode" value="all">
                        <span>Enviar para todos os provedores</span>
                    </label>
                </div>

                <div class="cm-providers-grid">
                    <?php foreach ($providers as $code => $name): ?>
                        <label class="cm-provider-card">
                            <input type="checkbox" class="provider-checkbox" value="<?php echo esc_attr($code); ?>">
                            <div class="cm-provider-name"><?php echo esc_html($name); ?></div>
                            <input type="number" class="provider-percent" data-provider="<?php echo esc_attr($code); ?>" 
                                   value="20" min="0" max="100">
                        </label>
                    <?php endforeach; ?>
                </div>

                <div id="distribution-summary" class="cm-summary"></div>
            </div>

            <!-- Limite de Registros -->
            <div class="cm-form-group">
                <label>📊 Limite de Registros (opcional)</label>
                <input type="number" id="record-limit" class="cm-input" placeholder="Ex: 1000" min="1">
                <small>Deixe vazio para enviar todos os registros filtrados</small>
            </div>

            <!-- Tipo de Agendamento -->
            <div class="cm-section">
                <h3>📅 Tipo de Agendamento</h3>
                
                <div class="cm-radio-group">
                    <label class="cm-radio">
                        <input type="radio" name="scheduling_mode" value="immediate" checked>
                        <span>Envio Imediato</span>
                    </label>
                    <label class="cm-radio">
                        <input type="radio" name="scheduling_mode" value="recurring">
                        <span>Salvar como Template</span>
                    </label>
                </div>

                <div id="recurring-options" style="display:none;">
                    <input type="text" id="campaign-name" class="cm-input" placeholder="Nome do template">
                </div>
            </div>

            <!-- Botão de Ação -->
            <button id="schedule-campaign-btn" class="cm-btn cm-btn-primary cm-btn-large" disabled>
                Agendar Campanha
            </button>

            <div id="schedule-message" class="cm-message"></div>
        </div>
    </div>
</div>